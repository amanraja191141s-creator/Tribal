const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ROOT = path.resolve(__dirname, '..');
const app = fs.readFileSync(path.join(ROOT, 'assets/js/app.js'), 'utf8');
const html = fs.readFileSync(path.join(ROOT, 'index.html'), 'utf8');
function extract(name) {
  const start = app.indexOf(`function ${name}(`);
  assert.notEqual(start, -1, `${name} must exist`);
  const open = app.indexOf('{', start); let depth = 0;
  for (let i = open; i < app.length; i++) {
    if (app[i] === '{') depth++;
    else if (app[i] === '}' && --depth === 0) return app.slice(start, i + 1);
  }
  throw new Error(`Unclosed ${name}`);
}

test('dedicated currency swap exchanges both amounts without converting away the displayed pair', () => {
  const context = { String };
  vm.runInNewContext(`${extract('getCurrencySwapAmounts')};globalThis.swap=getCurrencySwapAmounts;`, context);
  const swapped = context.swap('125.50', '10432.875');
  assert.equal(swapped.from, '10432.875');
  assert.equal(swapped.to, '125.50');
  assert.match(app, /getCurrencySwapAmounts\(getCurrencyAmountRaw\('cur-amount'\),getCurrencyAmountRaw\('cur-to-amount'\)\)/);
  assert.match(app, /setCurrencyAmountRaw\('cur-amount',swappedAmounts\.from,false\)/);
  assert.match(app, /setCurrencyAmountRaw\('cur-to-amount',swappedAmounts\.to,true\)/);
});

test('destination amount is honestly exposed as an editable accessible numeric field', () => {
  const match = html.match(/<div class="input-val-box currency-amount-input currency-result-input" id="cur-to-amount"[^>]*>/);
  assert.ok(match, 'destination amount field must exist');
  assert.match(match[0], /role="textbox"/);
  assert.match(match[0], /aria-readonly="false"/);
  assert.match(match[0], /inputmode="decimal"/);
  assert.match(match[0], /tabindex="0"/);
  assert.doesNotMatch(match[0], /aria-readonly="true"|tabindex="-1"|data-readonly="true"/);
});

test('both currency amount fields are included in the converter keypad navigation and reverse calculation path', () => {
  assert.match(app, /#screen-\$\{STATE\.currentScreen\} \.input-val-box/);
  assert.match(app, /const editingTo = active === toEl/);
  assert.match(app, /if \(editingTo && toValid\)/);
  assert.match(app, /decimalDivide\(toRaw, oneRateRaw, 12\)/);
});


test('rate status and checked/updated timestamps remain visible and accessible', () => {
  const status = html.match(/<span class="currency-rate-status" id="cur-rate-status"[^>]*>/);
  const timestamp = html.match(/<span class="currency-refresh-time" id="cur-refresh-time"[^>]*>/);
  assert.ok(status && timestamp);
  assert.match(status[0], /role="status"/);
  assert.match(status[0], /aria-live="polite"/);
  assert.doesNotMatch(status[0], /hidden|aria-hidden="true"/);
  assert.match(timestamp[0], /aria-live="polite"/);
  assert.doesNotMatch(timestamp[0], /hidden|aria-hidden="true"/);
  assert.match(app, /status\.hidden = false/);
  assert.match(fs.readFileSync(path.join(ROOT, 'assets/css/app.css'), 'utf8'), /#screen-currencies \.currency-rate-status \{ display:block !important/);
});
