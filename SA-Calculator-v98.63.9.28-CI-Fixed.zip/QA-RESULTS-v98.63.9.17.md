# QA results — v98.63.9.17

## Automated checks
- Full Node regression suite: **405/405 passed**, 0 failed.
- JavaScript syntax check (`node --check assets/js/app.js`): passed.
- Android web bundle preparation: passed; 13 required assets verified and the single canonical stylesheet copied.
- Release identity synchronized: package `1.98.65-v98.63.9.17`, runtime, HTML, PWA manifest, service worker and Android workflow.
- Android versionCode derived from package semver: `1098065`; workflow APK identity gate matches.
- YAML parsed successfully; ZIP integrity checked after packaging.

## New regression coverage
- Portrait display/keypad split is 36:64.
- Key button height increased to 96% of its grid cell; zero retains two-column span.
- Editable expression fitting range: 30px to 18px.
- Live preview fitting range: 56px to 22px, with runtime `!important` application.
- Committed result fitting range: 64px to 22px.
- Canonical calculation values remain unchanged by display-only scientific compaction.

## Not device-certified
This environment did not install the generated APK on the user's Android handset or run physical touch/performance profiling. Final WebView visual confirmation remains a device-side check.
