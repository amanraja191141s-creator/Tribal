import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),"..");
const read=p=>fs.readFileSync(path.join(root,p),"utf8");
const html=read("index.html"), css=read("assets/css/app.css"), sw=read("service-worker.js");
const ids=["calc","currencies","units","discount","percent","salestax","bodymetrics","date","fuelcost","fuelefficiency","gradeavg","hex","loan","savings","tip","unitprice","worldtime","settings"];
test("v98.37 all 18 source-defined screens remain present exactly once",()=>{
 for(const id of ids) assert.equal((html.match(new RegExp(`id=\"screen-${id}\"` ,"g"))||[]).length,1,`screen ${id}`);
});
test("v98.37 shared premium UI covers every tool screen without changing IDs",()=>{
 assert.match(html,/assets\/css\/app\.css/);
 assert.match(css,/#screen-viewport \.screen:not\(#screen-calc\) \.calc-card/);
 assert.match(css,/@media \(max-width: 380px\)/);
 assert.match(css,/prefers-reduced-motion/);
});
test("v98.37 service worker precaches the exact premium stylesheet",()=>assert.match(sw,/\.\/assets\/css\/app\.css/));
